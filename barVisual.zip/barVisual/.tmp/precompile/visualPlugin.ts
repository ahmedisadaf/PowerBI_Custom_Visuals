module powerbi.visuals.plugins {
    export var PBI_CV_E098DC1B_B68D_4013_82A9_70510F8FAF91_DEBUG = {
        name: 'PBI_CV_E098DC1B_B68D_4013_82A9_70510F8FAF91_DEBUG',
        displayName: 'barVisual',
        class: 'Visual',
        version: '1.0.0',
        apiVersion: '1.5.0',
        create: (options: extensibility.visual.VisualConstructorOptions) => new powerbi.extensibility.visual.PBI_CV_E098DC1B_B68D_4013_82A9_70510F8FAF91.Visual(options),
        custom: true
    };
}
